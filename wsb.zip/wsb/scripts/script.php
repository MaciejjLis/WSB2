<?php
  echo "<hr>Skrypt<hr>";
 ?>
